---
name: Thimble Bug Report or Feature Request
about: Report a bug with Thimble or request a feature in Thimble
title: ''
labels: ''
assignees: ''

---

DEPRECATION NOTICE
==================

**THIS PROJECT HAS BEEN DEPRECATED. ANY ISSUES FILED MAY NOT RECEIVE A RESPONSE.**

Mozilla has made a strategic decision to sunset Thimble over the course of 2018-2019. We encourage you to check out [Glitch](https://glitch.com) and you can [read our blog post](https://medium.com/read-write-participate/a-note-about-thimble-b8ba0a51b8fd) to learn more about this partnership.

This also means that any issues, bugs, or pull requests created in this repository might not receive a reply or support. If you are encountering issues migrating your projects to Glitch or have questions about the partnership, [please send us an email at thimbleglitchsupport@mozilla.org](mailto:thimbleglitchsupport@mozilla.org).
