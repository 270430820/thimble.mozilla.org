module.exports = {
  DEFAULT_PROJECT_NAME_KEY: "untitledProject"
};
