module.exports = {
  data: require("./data"),
  metadata: require("./metadata"),
  file: require("./file")
};
