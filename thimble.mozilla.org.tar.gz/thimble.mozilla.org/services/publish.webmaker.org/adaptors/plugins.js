"use strict";

module.exports = [
  require(`lout`),
  require(`hapi-auth-bearer-token`)
];
