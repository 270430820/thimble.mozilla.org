ALTER TABLE `Users`
  CHANGE `sendCoorganizerRequestEmails` `sendCoorganizerNotificationEmails` TINYINT(1);
