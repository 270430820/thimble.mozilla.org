ALTER TABLE `Users`
  DROP COLUMN `avatar`,
  DROP COLUMN `displayName`,
  DROP COLUMN `emailHash`;
