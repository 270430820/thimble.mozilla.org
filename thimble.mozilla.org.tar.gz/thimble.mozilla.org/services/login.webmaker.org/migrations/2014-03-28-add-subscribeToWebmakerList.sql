ALTER TABLE `Users` ADD COLUMN `subscribeToWebmakerList` tinyint(1) NOT NULL DEFAULT '0';
