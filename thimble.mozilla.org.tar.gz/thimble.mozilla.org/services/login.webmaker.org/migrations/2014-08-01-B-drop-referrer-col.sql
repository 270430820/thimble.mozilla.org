ALTER TABLE `Users`
  DROP COLUMN `referrer`;
